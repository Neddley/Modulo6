from django.contrib import admin
from .models import Vehiculos
# Register your models here.
admin.site.register(Vehiculos)
