#Proyecto Vehiculos

##Inicio aplicacion

pip3 install requirements.txt

crear entorno y levantar

ingresar a carpeta proyecto_vehiculos_django

iniciar con runserver
python3 manage.py runserver

##Usuarios
Usuario: admin - Password: admin